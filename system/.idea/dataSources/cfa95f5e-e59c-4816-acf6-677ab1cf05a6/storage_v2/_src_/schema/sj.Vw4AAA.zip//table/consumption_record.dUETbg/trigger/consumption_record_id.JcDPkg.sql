create definer = root@localhost trigger consumption_record_id
    before insert
    on consumption_record
    for each row
begin
    if new.id = -1 then
        select max(id) from consumption_record into @max_id;

        if @max_id is null then
            set new.id = 1;
        else
            set new.id = @max_id + 1;
        end if;
    end if;
end;

