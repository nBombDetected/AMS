create definer = root@localhost trigger update_inventory_consumption
    after insert
    on consumption_record
    for each row
begin
    if new.valid = 1 then
        select amount from accessory where item_id = new.item_id and valid = 1 into @amount;
        set @amount = @amount - new.amount;
        update accessory set amount = @amount where item_id = new.item_id and valid = 1;
    end if;
end;

